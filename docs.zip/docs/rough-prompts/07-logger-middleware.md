- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a comprehensive prompt form this 

need a robust, gdpr compliant logger middleware for my backend projects
make it inside backend libs package