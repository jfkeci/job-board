- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a prompts form this 

need a chakra-ui design system package that will be shared across all nextjs frontend applications.
the inspiration for the design system should be glassmorphism