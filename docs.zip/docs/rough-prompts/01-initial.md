- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a prompts form this 

need a turborepo setup for a nextjs typescript frontend app, nestjs api backend app, shared types package, shared backend library package, shared backend eslint/prettier package and shared frontend eslint/prettier package 