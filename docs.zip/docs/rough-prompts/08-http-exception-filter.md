- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a comprehensive prompt form this 

need a robust stripe inspired http exception filter library.
there should be exception codes and related internationalized messages for HR, BS, EN and MK languages.
language should be extracted from x-language header.
this exception filters will be used by nestjs apis.
exceptions should return
- code
- message
- stack

note
- consider validation messages separately