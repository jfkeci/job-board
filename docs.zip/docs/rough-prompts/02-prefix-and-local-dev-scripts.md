- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a prompts form this 

all apps/packages should have @borg prefix
need local dev script for the api and the website 
need another website that will be used as a b2b dashboard