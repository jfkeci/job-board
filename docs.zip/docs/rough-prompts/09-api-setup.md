- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a comprehensive prompt form this 

setup the main api, @borg/api
use config package, backend libs logger middleware and database package to establish a connection
also add swagger documentation, validation pipes
and a verbose healthcheck endpoint