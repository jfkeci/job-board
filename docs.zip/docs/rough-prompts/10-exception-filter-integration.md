- docs/ai-task-execution-workflow.md
- docs/prompts/template-prompt.md
- docs/prompts/00-prompt-header-reference.md

refine a comprehensive prompt form this 

borg/api needs to use the exception filter from backend libs